﻿namespace Bookstore.Domain.ReferenceData
{
    public class ReferenceDataFilters
    {
        public ReferenceDataType? ReferenceDataType { get; set; }
    }
}
