﻿namespace Bookstore.Domain.ReferenceData
{
    public enum ReferenceDataType
    {
        Publisher = 0,
        Condition = 1,
        BookType = 2,
        Genre = 3
    }
}
