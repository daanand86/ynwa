﻿namespace Bookstore.Domain.Books
{
    public class BookStatistics
    {
        public int OutOfStock { get; set; }

        public int LowStock { get; set; }

        public int StockTotal { get; set; }
    }
}
