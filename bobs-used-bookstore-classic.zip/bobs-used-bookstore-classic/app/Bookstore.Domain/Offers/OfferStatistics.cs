﻿namespace Bookstore.Domain.Orders
{
    public class OfferStatistics
    {
        public int PendingOffers { get; set; }

        public int OffersThisMonth { get; set; }

        public int OffersTotal { get; set; }
    }
}